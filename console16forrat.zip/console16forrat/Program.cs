﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;

namespace console16forrat
{
    class Program
    {
        static void Main(string[] args)
        {

            /*
            string stroka = "";
            if (File.Exists("file1.txt"))
            {
                StreamReader sr = File.OpenText("file1.txt");
                while (!sr.EndOfStream)
                {
                    stroka = sr.ReadLine();
                    Console.WriteLine("из файла:");
                    Console.WriteLine(stroka);
                }
                sr.Close();
                Console.WriteLine("введите слово:");
                string word = Console.ReadLine().ToLower();
                if (word == ""||word==" ")
                { Console.WriteLine("слово введено некорректно"); }
                else {
                    int count = stroka.ToLower().Split(' ', ',', '.',':').Count(s => s == word);
                    Console.WriteLine($"были найдены {count} вхождения(ий) поискового запроса '{word}' ");  
                }
            }
            else Console.WriteLine("файл не найден");*/


            if (File.Exists("rez.txt"))
            {
                using (StreamWriter sw= new StreamWriter("rez.txt"))
                {
                    Console.WriteLine("Введите элементы массива, разделенные пробелом:");
                    string[] array = Console.ReadLine().Split(' ');

                    int digitcount = array.SelectMany(s => s.Where(char.IsDigit)).Count();
                    Console.WriteLine($"Количество цифр в массиве: {digitcount}");

                    Console.WriteLine("Элементы массива до символа '/':");
                    bool slash = false;
                    foreach (string s in array)
                    {
                        if (s.Contains("/"))
                        {
                            slash = true;
                            break;
                        }
                        Console.Write($"{s}");
                    }
                    Console.WriteLine("\nЭлементы массива после символа '/' с заменой регистра:");

                    var result1 = array.SkipWhile(s => s != "/").Select(s => string.Concat(s.Select(c => char.IsUpper(c) ? char.ToLower(c) : char.ToUpper(c))));

                   
                    foreach (var item in result1)
                    {
                        Console.Write($"{item}");
                    }
                }
                    
            }
            else Console.WriteLine("файл для записи не найден");
            






            Console.ReadKey();
        }
       
       
    }
}
